<?php
/**
 * This file handles landing page elements
 *
 * @package Esotera
 */

esotera_lpslider();
esotera_lpblocks();
esotera_lptext('one');
esotera_lpboxes(1);
esotera_lptext('two');
esotera_lpboxes(2);
esotera_lptext('three');
esotera_lpindex();
esotera_lptext('four');
		
// FIN