jQuery(document).ready(function($) {
    
    $('#upload-btn').click(function(){
		$('#optionsframework form').attr('action','');
	});
    
  
});
